# CrawlerVision — Build an installable Android APK from your Samsung phone

**The included file is source code, not an APK.** GitHub Actions can compile it in the cloud; then you download `CrawlerVision-Test.apk` on your phone. No Android Studio or PC required.

## What you have
- `CrawlerVision_Android_Source.zip`: Android Java project containing six generic artwork frames. It requests Android notification-listener permission to inspect active media sessions and probe whether Amazon Music publishes a usable playback position. It does not record audio and has no INTERNET permission.
- `.github/workflows/build-apk.yml`: automated Android Gradle 8.11.1 / Android SDK 35 build that signs a debug APK automatically. The job stores a zipped APK in Actions and also attempts to publish an APK file in GitHub Releases.

## Phone-only steps
1. Sign into https://github.com in Chrome (turn on **Desktop site** if the mobile layout hides controls).
2. At https://github.com/new create a **new private repository** called `CrawlerVision`. Add a README when creating it so it has a default `main` branch.
3. In the new repo choose **Add file → Upload files**. Select `CrawlerVision_Android_Source.zip` from Downloads and commit to `main`. Do **not** unzip it first.
4. Choose **Add file → Create new file**. In its filename field type exactly `.github/workflows/build-apk.yml`. Copy/paste the contents of the similarly named YAML file included in this kit, then **Commit changes** to `main`.
5. Open the repository's **Actions** tab, select **Build CrawlerVision APK** and inspect the latest run. (If Actions are disabled, enable Actions for the repository under Settings → Actions.)
6. When the build passes, open **Releases** in the repository. Download `CrawlerVision-Test.apk` directly. If the Release step has an access restriction, use the run's **Artifacts** named `CrawlerVision-Test-APK`, download the ZIP, and extract `app-debug.apk`.
7. On your Samsung, tap the `.apk` in My Files → Downloads. If Samsung prompts, permit **Install unknown apps** for the file manager/browser that opened it; only permit the source you trust. You can turn this permission off again afterward.
8. Launch **CrawlerVision Test**. Press **Grant notification access**, grant it to CrawlerVision playback sync, start the audiobook in Amazon Music, then return to CrawlerVision. The app displays the playback title, state, and timestamp *if* Amazon publishes them. Tap **Copy playback diagnostics** and share the output for review.

## Important limits
- The APK **is a debug-signed test application**, not a Play Store release, and has **not been tested on your exact phone**.
- Amazon Music **may not expose** audiobook timeline position through Android media sessions; automatic slideshow syncing is conditional on the result.
- The images are **generic test frames**, not AI-generated scene illustrations for the novel.
- Revoking notification access after testing is advisable if you do not plan to keep using it.
- If build fails, review the job log under **Actions → Build CrawlerVision APK → build** and share the error with ChatGPT. A workflow run will not continue without user action, and ChatGPT cannot independently install an APK on your phone.
